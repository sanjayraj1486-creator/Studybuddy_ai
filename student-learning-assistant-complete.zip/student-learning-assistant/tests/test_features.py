from __future__ import annotations

import json
import unittest
from typing import Literal

from features.chatbot import ConversationHistory, StudyChatbot
from features.explainer import ConceptExplainer
from features.quiz import QuizFormatError, QuizGenerator
from features.summarizer import TextSummarizer
from features.validation import InputValidationError
from llm.base import ChatMessage, LLMClient, LLMClientError
from llm.provider import get_llm_client


class _MockLLMClient:
    """Test-only mock client inside the test suite; no external API calls."""

    def __init__(self, handler) -> None:
        self._handler = handler
        self.calls: list[dict] = []

    def generate(
        self,
        messages: list[ChatMessage],
        *,
        temperature: float = 0.2,
        response_format: Literal["text", "json"] = "text",
    ) -> str:
        self.calls.append(
            {
                "messages": list(messages),
                "temperature": temperature,
                "response_format": response_format,
            }
        )
        return self._handler(messages, response_format)


class TestStudentLearningAssistantFeatures(unittest.TestCase):
    def test_client_satisfies_protocol_and_default_provider_unconfigured(self) -> None:
        mock_client = _MockLLMClient(lambda msgs, fmt: "ready")
        self.assertIsInstance(mock_client, LLMClient)

        default_client = get_llm_client()
        self.assertIsInstance(default_client, LLMClient)
        with self.assertRaises(LLMClientError):
            default_client.generate([ChatMessage(role="user", content="hello")])

    def test_explainer_beginner_mode_and_validation(self) -> None:
        mock_client = _MockLLMClient(lambda msgs, fmt: f"Explanation for {msgs[-1].content}")
        explainer = ConceptExplainer(mock_client)

        res = explainer.explain("Gravity", topic="Physics", beginner_friendly=True)
        self.assertEqual(res.concept, "Gravity")
        self.assertEqual(res.topic, "Physics")
        self.assertTrue(res.beginner_friendly)
        self.assertIn("beginner-friendly", mock_client.calls[0]["messages"][0].content.lower())

        with self.assertRaises(InputValidationError):
            explainer.explain(" ")

    def test_summarizer_and_validation(self) -> None:
        mock_client = _MockLLMClient(lambda msgs, fmt: "- Point A\n- Point B")
        summarizer = TextSummarizer(mock_client)
        sample = "Mitochondria generate ATP through cellular respiration using oxygen and nutrients."

        res = summarizer.summarize(sample, max_bullets=4, beginner_friendly=True)
        self.assertEqual(res.max_bullets, 4)
        self.assertIn("Point A", res.summary)

        with self.assertRaises(InputValidationError):
            summarizer.summarize("Short text")

    def test_quiz_generator_mcq_structure_and_validation(self) -> None:
        payload = {
            "questions": [
                {
                    "question": "Which organelle produces ATP?",
                    "options": [
                        {"label": "A", "text": "Mitochondrion"},
                        {"label": "B", "text": "Ribosome"},
                        {"label": "C", "text": "Golgi apparatus"},
                        {"label": "D", "text": "Lysosome"},
                    ],
                    "correct_label": "A",
                    "explanation": "Mitochondria are the site of cellular respiration and ATP production.",
                }
            ]
        }
        mock_client = _MockLLMClient(
            lambda msgs, fmt: json.dumps(payload) if fmt == "json" else ""
        )
        gen = QuizGenerator(mock_client)

        quiz = gen.generate(
            "Cell biology basics",
            num_questions=1,
            num_options=4,
            difficulty="beginner",
            beginner_friendly=True,
        )
        self.assertEqual(len(quiz.questions), 1)
        self.assertEqual(quiz.questions[0].correct_label, "A")
        self.assertEqual(len(quiz.questions[0].options), 4)

        bad_client = _MockLLMClient(lambda msgs, fmt: "{bad json")
        with self.assertRaises(QuizFormatError):
            QuizGenerator(bad_client).generate("Cell biology basics", num_questions=1, num_options=4)

        with self.assertRaises(InputValidationError):
            gen.generate("Cell biology basics", num_options=1)

    def test_chatbot_preserves_conversation_history(self) -> None:
        def reply_fn(msgs: list[ChatMessage], fmt: str) -> str:
            user_msgs = [m.content for m in msgs if m.role == "user"]
            return f"Response #{len(user_msgs)}: {user_msgs[-1]}"

        mock_client = _MockLLMClient(reply_fn)
        bot = StudyChatbot(mock_client)
        history = ConversationHistory()

        r1, _ = bot.send_message("What is a prime number?", history, beginner_friendly=True)
        self.assertIn("Response #1", r1)

        r2, updated = bot.send_message("Give me an example.", history, beginner_friendly=True)
        self.assertIn("Response #2", r2)
        self.assertEqual(len(history.messages), 4)
        self.assertEqual(len(updated), 4)

        sent_user_msgs = [m.content for m in mock_client.calls[1]["messages"] if m.role == "user"]
        self.assertEqual(sent_user_msgs, ["What is a prime number?", "Give me an example."])

        with self.assertRaises(InputValidationError):
            bot.send_message("", history)


if __name__ == "__main__":
    unittest.main()
