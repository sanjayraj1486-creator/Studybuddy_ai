from __future__ import annotations

import streamlit as st

from config.settings import get_settings
from llm.provider import get_llm_client
from ui.components import render_sidebar_controls
from ui.pages.chatbot import render_chatbot_page
from ui.pages.explainer import render_explainer_page
from ui.pages.quiz import render_quiz_page
from ui.pages.summarizer import render_summarizer_page
from ui.styles import apply_custom_styles


def main() -> None:
    settings = get_settings()
    st.set_page_config(page_title=settings.app_title, layout="wide")
    apply_custom_styles()

    st.title(settings.app_title)
    page, beginner_friendly = render_sidebar_controls(
        default_beginner=settings.default_beginner_mode
    )
    client = get_llm_client()

    if page == "Concept Explainer":
        render_explainer_page(client, beginner_friendly=beginner_friendly)
    elif page == "Text Summarizer":
        render_summarizer_page(client, beginner_friendly=beginner_friendly)
    elif page == "Quiz Generator":
        render_quiz_page(client, beginner_friendly=beginner_friendly)
    elif page == "Study Chatbot":
        render_chatbot_page(client, beginner_friendly=beginner_friendly)


if __name__ == "__main__":
    main()
