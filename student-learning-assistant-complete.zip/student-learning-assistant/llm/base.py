from __future__ import annotations

from dataclasses import dataclass
from typing import Literal, Protocol, runtime_checkable

MessageRole = Literal["system", "user", "assistant"]


@dataclass(frozen=True)
class ChatMessage:
    """Single message in a conversation passed to an LLMClient."""

    role: MessageRole
    content: str


class LLMClientError(Exception):
    """Raised when an LLMClient encounters an execution error."""


@runtime_checkable
class LLMClient(Protocol):
    """Abstract interface for language model clients."""

    def generate(
        self,
        messages: list[ChatMessage],
        *,
        temperature: float = 0.2,
        response_format: Literal["text", "json"] = "text",
    ) -> str:
        """Generate text or JSON output from a sequence of chat messages."""
        ...
