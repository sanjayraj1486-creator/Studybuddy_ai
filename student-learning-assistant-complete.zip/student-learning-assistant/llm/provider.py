from __future__ import annotations

from typing import Literal

from llm.base import ChatMessage, LLMClient, LLMClientError


class UnconfiguredProviderClient:
    """Placeholder client; no external API provider is connected in this phase."""

    def generate(
        self,
        messages: list[ChatMessage],
        *,
        temperature: float = 0.2,
        response_format: Literal["text", "json"] = "text",
    ) -> str:
        raise LLMClientError(
            "No external LLM API provider is connected yet. "
            "Inject an LLMClient implementation (such as a test mock) when running features."
        )


def get_llm_client() -> LLMClient:
    """Return the configured LLMClient instance without connecting an external API."""
    return UnconfiguredProviderClient()
