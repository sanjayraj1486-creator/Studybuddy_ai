from __future__ import annotations

from dataclasses import dataclass, field

from features.validation import validate_chat_input
from llm.base import ChatMessage, LLMClient


@dataclass
class ConversationHistory:
    """Stores ordered chat turns so context is preserved across exchanges."""

    messages: list[ChatMessage] = field(default_factory=list)

    def add_exchange(self, user_text: str, assistant_text: str) -> None:
        self.messages.append(ChatMessage(role="user", content=user_text))
        self.messages.append(ChatMessage(role="assistant", content=assistant_text))

    def clear(self) -> None:
        self.messages.clear()


def build_chatbot_prompts(
    history: list[ChatMessage],
    user_message: str,
    *,
    beginner_friendly: bool = True,
) -> list[ChatMessage]:
    style_note = (
        "Keep responses warm, clear, and beginner-friendly unless the student asks for advanced depth."
        if beginner_friendly
        else "Keep responses clear, accurate, and tailored to the student's follow-up questions."
    )
    system_msg = ChatMessage(
        role="system",
        content=(
            "You are StudyBuddy AI's Study Chatbot. "
            "Use the conversation history to stay consistent across turns, answer follow-ups directly, "
            f"and help the student learn actively. {style_note}"
        ),
    )
    prior_turns = [msg for msg in history if msg.role != "system"]
    return [
        system_msg,
        *prior_turns,
        ChatMessage(role="user", content=user_message),
    ]


class StudyChatbot:
    """Interactive study chatbot that preserves conversation history via LLMClient."""

    def __init__(self, client: LLMClient) -> None:
        self._client = client

    def send_message(
        self,
        user_message: str,
        history: list[ChatMessage] | ConversationHistory,
        *,
        beginner_friendly: bool = True,
    ) -> tuple[str, list[ChatMessage]]:
        prior_messages = history.messages if isinstance(history, ConversationHistory) else history
        cleaned_msg, validated_history = validate_chat_input(user_message, prior_messages)

        prompt_messages = build_chatbot_prompts(
            validated_history,
            cleaned_msg,
            beginner_friendly=beginner_friendly,
        )
        assistant_reply = self._client.generate(
            prompt_messages,
            temperature=0.3 if beginner_friendly else 0.2,
            response_format="text",
        ).strip()

        updated_history = [
            *validated_history,
            ChatMessage(role="user", content=cleaned_msg),
            ChatMessage(role="assistant", content=assistant_reply),
        ]
        if isinstance(history, ConversationHistory):
            history.messages = list(updated_history)

        return assistant_reply, updated_history
