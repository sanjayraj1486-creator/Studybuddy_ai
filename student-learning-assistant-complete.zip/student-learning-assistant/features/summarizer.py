from __future__ import annotations

from dataclasses import dataclass

from features.validation import validate_summary_input
from llm.base import ChatMessage, LLMClient


@dataclass(frozen=True)
class TextSummary:
    summary: str
    max_bullets: int
    beginner_friendly: bool


def build_summary_prompts(
    text: str,
    *,
    max_bullets: int = 5,
    beginner_friendly: bool = True,
) -> list[ChatMessage]:
    style_instructions = (
        "Write in simple, beginner-friendly language that makes new terms easy to grasp."
        if beginner_friendly
        else "Write a crisp, structured academic summary preserving technical precision."
    )

    system_msg = ChatMessage(
        role="system",
        content=(
            "You are StudyBuddy AI's Text Summarizer. "
            "Summarize only what is supported by the provided text without adding outside facts. "
            f"Include a brief overview and at most {max_bullets} bullet points of key takeaways. "
            f"{style_instructions}"
        ),
    )
    user_msg = ChatMessage(
        role="user",
        content=(
            f"Max bullet points: {max_bullets}\n"
            f"Beginner-friendly mode: {'ON' if beginner_friendly else 'OFF'}\n\n"
            f"Text to summarize:\n\"\"\"\n{text}\n\"\"\""
        ),
    )
    return [system_msg, user_msg]


class TextSummarizer:
    """Summarizes study text using an LLMClient."""

    def __init__(self, client: LLMClient) -> None:
        self._client = client

    def summarize(
        self,
        text: str,
        *,
        max_bullets: int = 5,
        beginner_friendly: bool = True,
    ) -> TextSummary:
        cleaned_text, valid_bullets = validate_summary_input(text, max_bullets=max_bullets)
        messages = build_summary_prompts(
            cleaned_text,
            max_bullets=valid_bullets,
            beginner_friendly=beginner_friendly,
        )
        output = self._client.generate(
            messages,
            temperature=0.2,
            response_format="text",
        )
        return TextSummary(
            summary=output.strip(),
            max_bullets=valid_bullets,
            beginner_friendly=beginner_friendly,
        )
