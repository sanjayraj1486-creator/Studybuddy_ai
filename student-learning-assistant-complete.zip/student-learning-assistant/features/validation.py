from __future__ import annotations

from llm.base import ChatMessage


class InputValidationError(ValueError):
    """Raised when user inputs for a learning feature are invalid."""


def _clean_text(value: str, field_name: str, *, min_len: int, max_len: int) -> str:
    if not isinstance(value, str):
        raise InputValidationError(f"{field_name} must be a string.")
    cleaned = value.strip()
    if len(cleaned) < min_len:
        raise InputValidationError(f"{field_name} must be at least {min_len} character(s).")
    if len(cleaned) > max_len:
        raise InputValidationError(f"{field_name} must not exceed {max_len} characters.")
    return cleaned


def validate_concept_input(concept: str, topic: str | None = None) -> tuple[str, str | None]:
    cleaned_concept = _clean_text(concept, "Concept", min_len=2, max_len=300)
    cleaned_topic: str | None = None
    if topic is not None and topic.strip():
        cleaned_topic = _clean_text(topic, "Topic", min_len=2, max_len=120)
    return cleaned_concept, cleaned_topic


def validate_summary_input(text: str, max_bullets: int = 5) -> tuple[str, int]:
    cleaned_text = _clean_text(text, "Study text", min_len=20, max_len=30000)
    if not isinstance(max_bullets, int) or isinstance(max_bullets, bool):
        raise InputValidationError("max_bullets must be an integer.")
    if not (1 <= max_bullets <= 15):
        raise InputValidationError("max_bullets must be between 1 and 15.")
    return cleaned_text, max_bullets


def validate_quiz_input(
    material: str,
    num_questions: int = 5,
    num_options: int = 4,
    difficulty: str = "beginner",
) -> tuple[str, int, int, str]:
    cleaned_material = _clean_text(material, "Quiz topic or material", min_len=3, max_len=25000)
    if not isinstance(num_questions, int) or isinstance(num_questions, bool):
        raise InputValidationError("num_questions must be an integer.")
    if not (1 <= num_questions <= 20):
        raise InputValidationError("num_questions must be between 1 and 20.")
    if not isinstance(num_options, int) or isinstance(num_options, bool):
        raise InputValidationError("num_options must be an integer.")
    if not (2 <= num_options <= 6):
        raise InputValidationError("num_options must be between 2 and 6.")

    cleaned_diff = _clean_text(difficulty, "Difficulty", min_len=2, max_len=40).lower()
    allowed = ("beginner", "intermediate", "advanced")
    if cleaned_diff not in allowed:
        raise InputValidationError(f"Difficulty must be one of: {', '.join(allowed)}.")
    return cleaned_material, num_questions, num_options, cleaned_diff


def validate_chat_input(message: str, history: list[ChatMessage]) -> tuple[str, list[ChatMessage]]:
    cleaned_msg = _clean_text(message, "Message", min_len=1, max_len=4000)
    if not isinstance(history, list):
        raise InputValidationError("History must be a list of ChatMessage objects.")
    for item in history:
        if not isinstance(item, ChatMessage):
            raise InputValidationError("Every history item must be a ChatMessage.")
        if item.role not in ("system", "user", "assistant"):
            raise InputValidationError(f"Invalid message role: {item.role}")
        if not item.content or not item.content.strip():
            raise InputValidationError("History messages cannot be empty.")
    return cleaned_msg, list(history)
