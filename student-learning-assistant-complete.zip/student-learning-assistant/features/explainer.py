from __future__ import annotations

from dataclasses import dataclass

from features.validation import validate_concept_input
from llm.base import ChatMessage, LLMClient


@dataclass(frozen=True)
class ConceptExplanation:
    concept: str
    topic: str | None
    beginner_friendly: bool
    explanation: str


def build_concept_prompts(
    concept: str,
    *,
    topic: str | None = None,
    beginner_friendly: bool = True,
) -> list[ChatMessage]:
    level_instructions = (
        "Use beginner-friendly language: avoid unexplained jargon, define terms simply, "
        "and include a relatable everyday analogy."
        if beginner_friendly
        else "Provide a clear, structured explanation suitable for a student with foundational knowledge."
    )
    topic_line = f"Subject / Topic: {topic}\n" if topic else ""

    system_msg = ChatMessage(
        role="system",
        content=(
            "You are StudyBuddy AI's Concept Explainer. "
            "Organize your response clearly into: "
            "1) Core Idea in Plain Words, 2) Step-by-Step Breakdown, "
            "3) Everyday Example or Analogy, and 4) Key Takeaway. "
            f"{level_instructions}"
        ),
    )
    user_msg = ChatMessage(
        role="user",
        content=(
            f"{topic_line}"
            f"Concept: {concept}\n"
            f"Beginner-friendly mode: {'ON' if beginner_friendly else 'OFF'}"
        ),
    )
    return [system_msg, user_msg]


class ConceptExplainer:
    """Explains concepts clearly using an LLMClient."""

    def __init__(self, client: LLMClient) -> None:
        self._client = client

    def explain(
        self,
        concept: str,
        *,
        topic: str | None = None,
        beginner_friendly: bool = True,
    ) -> ConceptExplanation:
        cleaned_concept, cleaned_topic = validate_concept_input(concept, topic)
        messages = build_concept_prompts(
            cleaned_concept,
            topic=cleaned_topic,
            beginner_friendly=beginner_friendly,
        )
        output = self._client.generate(
            messages,
            temperature=0.3 if beginner_friendly else 0.2,
            response_format="text",
        )
        return ConceptExplanation(
            concept=cleaned_concept,
            topic=cleaned_topic,
            beginner_friendly=beginner_friendly,
            explanation=output.strip(),
        )
