from __future__ import annotations

import json
from dataclasses import dataclass

from features.validation import validate_quiz_input
from llm.base import ChatMessage, LLMClient


class QuizFormatError(ValueError):
    """Raised when the model's quiz output does not match the expected MCQ structure."""


@dataclass(frozen=True)
class ChoiceOption:
    label: str
    text: str


@dataclass(frozen=True)
class MultipleChoiceQuestion:
    question: str
    options: list[ChoiceOption]
    correct_label: str
    explanation: str


@dataclass(frozen=True)
class QuizSet:
    topic: str
    difficulty: str
    beginner_friendly: bool
    questions: list[MultipleChoiceQuestion]


def build_quiz_prompts(
    material: str,
    *,
    num_questions: int = 5,
    num_options: int = 4,
    difficulty: str = "beginner",
    beginner_friendly: bool = True,
) -> list[ChatMessage]:
    labels = ", ".join(chr(ord("A") + i) for i in range(num_options))
    tone_note = (
        "Use clear, beginner-friendly wording in both questions and answer explanations."
        if beginner_friendly
        else "Write clear multiple-choice questions testing conceptual understanding."
    )

    system_msg = ChatMessage(
        role="system",
        content=(
            "You are StudyBuddy AI's Quiz Generator. "
            "Respond ONLY with valid JSON matching this schema:\n"
            "{\n"
            '  "questions": [\n'
            "    {\n"
            '      "question": "string",\n'
            '      "options": [{"label": "A", "text": "string"}],\n'
            '      "correct_label": "A",\n'
            '      "explanation": "string"\n'
            "    }\n"
            "  ]\n"
            "}\n"
            f"Each question must have {num_options} options using labels: {labels}. "
            f"Difficulty level: {difficulty}. {tone_note}"
        ),
    )
    user_msg = ChatMessage(
        role="user",
        content=(
            f"Create {num_questions} multiple-choice questions based on:\n\"\"\"\n{material}\n\"\"\""
        ),
    )
    return [system_msg, user_msg]


def _parse_quiz_json(
    raw_text: str,
    *,
    topic: str,
    difficulty: str,
    beginner_friendly: bool,
    expected_options: int,
) -> QuizSet:
    cleaned = raw_text.strip()
    if cleaned.startswith("```"):
        lines = cleaned.splitlines()
        if lines and lines[0].startswith("```"):
            lines = lines[1:]
        if lines and lines[-1].strip() == "```":
            lines = lines[:-1]
        cleaned = "\n".join(lines).strip()

    try:
        data = json.loads(cleaned)
    except json.JSONDecodeError as exc:
        raise QuizFormatError("Quiz output is not valid JSON.") from exc

    if not isinstance(data, dict) or not isinstance(data.get("questions"), list):
        raise QuizFormatError("Quiz JSON must include a 'questions' list.")

    raw_qs = data["questions"]
    if not raw_qs:
        raise QuizFormatError("Quiz JSON cannot have an empty 'questions' list.")

    questions: list[MultipleChoiceQuestion] = []
    for idx, item in enumerate(raw_qs, start=1):
        if not isinstance(item, dict):
            raise QuizFormatError(f"Question {idx} must be a JSON object.")

        q_text = item.get("question")
        if not isinstance(q_text, str) or not q_text.strip():
            raise QuizFormatError(f"Question {idx} is missing 'question' text.")

        raw_opts = item.get("options")
        if not isinstance(raw_opts, list) or len(raw_opts) != expected_options:
            raise QuizFormatError(
                f"Question {idx} must contain exactly {expected_options} options."
            )

        options: list[ChoiceOption] = []
        seen_labels: set[str] = set()
        for opt in raw_opts:
            if not isinstance(opt, dict):
                raise QuizFormatError(f"Option in question {idx} must be an object.")
            label = opt.get("label")
            opt_text = opt.get("text")
            if not isinstance(label, str) or not label.strip() or not isinstance(opt_text, str) or not opt_text.strip():
                raise QuizFormatError(f"Option in question {idx} requires non-empty label and text.")
            norm_label = label.strip().upper()
            if norm_label in seen_labels:
                raise QuizFormatError(f"Duplicate option label '{norm_label}' in question {idx}.")
            seen_labels.add(norm_label)
            options.append(ChoiceOption(label=norm_label, text=opt_text.strip()))

        correct = item.get("correct_label")
        if not isinstance(correct, str) or not correct.strip():
            raise QuizFormatError(f"Question {idx} is missing 'correct_label'.")
        norm_correct = correct.strip().upper()
        if norm_correct not in seen_labels:
            raise QuizFormatError(
                f"Question {idx} 'correct_label' ({norm_correct}) does not match any option."
            )

        explanation = item.get("explanation")
        if not isinstance(explanation, str) or not explanation.strip():
            raise QuizFormatError(f"Question {idx} is missing an 'explanation'.")

        questions.append(
            MultipleChoiceQuestion(
                question=q_text.strip(),
                options=options,
                correct_label=norm_correct,
                explanation=explanation.strip(),
            )
        )

    return QuizSet(
        topic=topic,
        difficulty=difficulty,
        beginner_friendly=beginner_friendly,
        questions=questions,
    )


class QuizGenerator:
    """Generates structured multiple-choice quizzes using an LLMClient."""

    def __init__(self, client: LLMClient) -> None:
        self._client = client

    def generate(
        self,
        material: str,
        *,
        num_questions: int = 5,
        num_options: int = 4,
        difficulty: str = "beginner",
        beginner_friendly: bool = True,
    ) -> QuizSet:
        cleaned_material, valid_q, valid_opts, valid_diff = validate_quiz_input(
            material,
            num_questions=num_questions,
            num_options=num_options,
            difficulty=difficulty,
        )
        messages = build_quiz_prompts(
            cleaned_material,
            num_questions=valid_q,
            num_options=valid_opts,
            difficulty=valid_diff,
            beginner_friendly=beginner_friendly,
        )
        raw_response = self._client.generate(
            messages,
            temperature=0.2,
            response_format="json",
        )
        short_topic = cleaned_material.splitlines()[0][:80].strip()
        return _parse_quiz_json(
            raw_response,
            topic=short_topic,
            difficulty=valid_diff,
            beginner_friendly=beginner_friendly,
            expected_options=valid_opts,
        )
