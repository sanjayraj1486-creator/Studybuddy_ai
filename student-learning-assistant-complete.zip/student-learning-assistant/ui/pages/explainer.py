from __future__ import annotations

import streamlit as st

from features.explainer import ConceptExplainer
from features.validation import InputValidationError
from llm.base import LLMClient, LLMClientError


def render_explainer_page(client: LLMClient, *, beginner_friendly: bool = True) -> None:
    st.header("Concept Explainer")
    topic = st.text_input("Topic (optional)", placeholder="e.g., Physics, Python")
    concept = st.text_input("Concept", placeholder="e.g., Newton's Second Law")

    if st.button("Explain", key="explainer_submit"):
        explainer = ConceptExplainer(client)
        try:
            result = explainer.explain(
                concept,
                topic=topic or None,
                beginner_friendly=beginner_friendly,
            )
            st.markdown(result.explanation)
        except (InputValidationError, LLMClientError) as exc:
            st.error(str(exc))
