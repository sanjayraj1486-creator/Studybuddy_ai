from __future__ import annotations

import streamlit as st

from features.quiz import QuizFormatError, QuizGenerator
from features.validation import InputValidationError
from llm.base import LLMClient, LLMClientError


def render_quiz_page(client: LLMClient, *, beginner_friendly: bool = True) -> None:
    st.header("Quiz Generator")
    material = st.text_area("Topic or Study Material", height=140)
    col1, col2, col3 = st.columns(3)
    with col1:
        num_questions = st.number_input("Questions", min_value=1, max_value=15, value=3, step=1)
    with col2:
        num_options = st.number_input("Options", min_value=2, max_value=6, value=4, step=1)
    with col3:
        difficulty = st.selectbox("Difficulty", options=["beginner", "intermediate", "advanced"], index=0)

    if st.button("Generate Quiz", key="quiz_submit"):
        generator = QuizGenerator(client)
        try:
            quiz_set = generator.generate(
                material,
                num_questions=int(num_questions),
                num_options=int(num_options),
                difficulty=str(difficulty),
                beginner_friendly=beginner_friendly,
            )
            st.session_state["quiz_set"] = quiz_set
        except (InputValidationError, QuizFormatError, LLMClientError) as exc:
            st.error(str(exc))

    quiz_set = st.session_state.get("quiz_set")
    if quiz_set:
        for idx, q in enumerate(quiz_set.questions, start=1):
            st.subheader(f"Question {idx}")
            st.write(q.question)
            option_labels = {f"{opt.label}. {opt.text}": opt.label for opt in q.options}
            selected = st.radio("Choose an option:", options=list(option_labels.keys()), key=f"q_{idx}")
            if selected:
                picked_label = option_labels[selected]
                if picked_label == q.correct_label:
                    st.success(f"Correct ({q.correct_label}): {q.explanation}")
                else:
                    st.info(f"Correct answer: {q.correct_label} — {q.explanation}")
