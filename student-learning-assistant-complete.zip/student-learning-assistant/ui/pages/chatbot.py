from __future__ import annotations

import streamlit as st

from features.chatbot import StudyChatbot
from features.validation import InputValidationError
from llm.base import LLMClient, LLMClientError


def render_chatbot_page(client: LLMClient, *, beginner_friendly: bool = True) -> None:
    st.header("Study Chatbot")
    if "study_chat_history" not in st.session_state:
        st.session_state["study_chat_history"] = []

    history = st.session_state["study_chat_history"]
    for msg in history:
        with st.chat_message(msg.role):
            st.markdown(msg.content)

    user_input = st.chat_input("Ask a study question...")
    if user_input is not None:
        bot = StudyChatbot(client)
        try:
            _, updated = bot.send_message(
                user_input,
                history,
                beginner_friendly=beginner_friendly,
            )
            st.session_state["study_chat_history"] = updated
            st.rerun()
        except (InputValidationError, LLMClientError) as exc:
            st.error(str(exc))
