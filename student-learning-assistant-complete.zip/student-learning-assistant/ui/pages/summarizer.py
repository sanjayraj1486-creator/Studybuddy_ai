from __future__ import annotations

import streamlit as st

from features.summarizer import TextSummarizer
from features.validation import InputValidationError
from llm.base import LLMClient, LLMClientError


def render_summarizer_page(client: LLMClient, *, beginner_friendly: bool = True) -> None:
    st.header("Text Summarizer")
    source_text = st.text_area("Study Text", height=180, placeholder="Paste notes or reading material...")
    max_bullets = st.slider("Maximum bullet points", min_value=1, max_value=10, value=5)

    if st.button("Summarize", key="summarizer_submit"):
        summarizer = TextSummarizer(client)
        try:
            result = summarizer.summarize(
                source_text,
                max_bullets=max_bullets,
                beginner_friendly=beginner_friendly,
            )
            st.markdown(result.summary)
        except (InputValidationError, LLMClientError) as exc:
            st.error(str(exc))
