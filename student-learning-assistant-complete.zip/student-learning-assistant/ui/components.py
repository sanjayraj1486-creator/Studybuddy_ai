from __future__ import annotations

import streamlit as st


def render_sidebar_controls(default_beginner: bool = True) -> tuple[str, bool]:
    st.sidebar.title("StudyBuddy AI")
    page = st.sidebar.radio(
        "Choose a Study Tool",
        options=[
            "Concept Explainer",
            "Text Summarizer",
            "Quiz Generator",
            "Study Chatbot",
        ],
    )
    beginner_friendly = st.sidebar.toggle(
        "Beginner-friendly explanations",
        value=default_beginner,
    )
    return page, beginner_friendly
