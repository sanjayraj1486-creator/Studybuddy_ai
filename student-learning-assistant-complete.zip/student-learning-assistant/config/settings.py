from __future__ import annotations

import os
from dataclasses import dataclass


@dataclass(frozen=True)
class AppSettings:
    app_title: str = "Student Learning Assistant"
    default_beginner_mode: bool = True
    llm_provider: str = os.getenv("LLM_PROVIDER", "unconfigured")


def get_settings() -> AppSettings:
    return AppSettings()
