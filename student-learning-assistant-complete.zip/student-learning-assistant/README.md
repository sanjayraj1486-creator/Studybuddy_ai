# Student Learning Assistant (StudyBuddy AI)

Modular Python + Streamlit study companion built with a clean separation between UI rendering, feature logic/prompting, and an abstract `LLMClient` interface.

## Project Structure

```text
student-learning-assistant/
├── app.py                     # Streamlit entry point
├── requirements.txt           # Python dependencies
├── .env.example               # Environment configuration template
├── .streamlit/config.toml     # Streamlit theme configuration
├── config/
│   └── settings.py            # Application settings
├── llm/
│   ├── base.py                # ChatMessage, LLMClient protocol, LLMClientError
│   └── provider.py            # Unconfigured provider placeholder (no external API wired yet)
├── features/
│   ├── validation.py          # Shared input validation for all four features
│   ├── explainer.py           # Concept Explainer (with beginner-friendly mode)
│   ├── summarizer.py          # Text Summarizer
│   ├── quiz.py                # Structured Multiple-Choice Quiz Generator
│   └── chatbot.py             # Multi-turn Study Chatbot with conversation history
├── ui/
│   ├── components.py          # Sidebar navigation & beginner-mode toggle
│   ├── styles.py              # Custom Streamlit layout styling
│   └── pages/
│       ├── explainer.py       # Streamlit UI for Concept Explainer
│       ├── summarizer.py      # Streamlit UI for Text Summarizer
│       ├── quiz.py            # Streamlit UI for Quiz Generator
│       └── chatbot.py         # Streamlit UI for Study Chatbot
└── tests/
    └── test_features.py       # Unit tests using a test-only MockLLMClient
```

## Running Tests

From the `student-learning-assistant/` root directory:

```bash
python -m unittest discover -s tests -v
```

## Running the Streamlit App

```bash
pip install -r requirements.txt
streamlit run app.py
```

> **Note:** `llm/provider.py` intentionally raises `LLMClientError` until a real LLM provider implementation is wired in during the next phase.
